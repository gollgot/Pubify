<?php

return [
    'settings' => [
        // Slim Settings
        'displayErrorDetails' => true,
        // DB Settings
        'db' => [
            'host' => 'localhost',
            'user' => 'homestead',
            'pass'  => 'secret',
            'dbname' => 'PUBify'
        ]
    ]
];